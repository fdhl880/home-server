const express = require('express');
const si = require('systeminformation');
const path = require('path');
const https = require('https');
const Parser = require('rss-parser');

const parser = new Parser();
const app = express();
const PORT = 4000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/stats', async (req, res) => {
    try {
        const cpu = await si.currentLoad();
        const mem = await si.mem();
        const os = await si.osInfo();
        const time = await si.time();
        res.json({
            cpu: cpu.currentLoad.toFixed(1),
            memTotal: (mem.total / 1024 / 1024 / 1024).toFixed(2),
            memUsed: (mem.active / 1024 / 1024 / 1024).toFixed(2),
            memPercent: ((mem.active / mem.total) * 100).toFixed(1),
            uptime: time.uptime,
            platform: os.platform
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/weather', (req, res) => {
    const url = 'https://api.open-meteo.com/v1/forecast?latitude=3.5952&longitude=98.6722&current_weather=true&timezone=Asia%2FJakarta';
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (response) => {
        let data = '';
        response.on('data', chunk => data += chunk);
        response.on('end', () => {
            try { res.json(JSON.parse(data)); } catch (e) { res.status(500).json({ error: 'Parse failed' }); }
        });
    }).on('error', (e) => res.status(500).json({ error: e.message }));
});

// Market Status (based on UTC hours)
app.get('/api/markets', (req, res) => {
    const now = new Date();
    const utcMin = now.getUTCHours() * 60 + now.getUTCMinutes();
    const day = now.getUTCDay();
    const isWeekday = day >= 1 && day <= 5;

    const isOpen = (openH, openM, closeH, closeM) => {
        const open = openH * 60 + openM;
        const close = closeH * 60 + closeM;
        return isWeekday && utcMin >= open && utcMin < close;
    };
    const isPre = (openH, openM) => {
        const open = openH * 60 + openM;
        return isWeekday && utcMin >= open - 60 && utcMin < open;
    };

    const status = (openH, openM, closeH, closeM) => {
        if (isOpen(openH, openM, closeH, closeM)) return 'OPEN';
        if (isPre(openH, openM)) return 'PRE';
        return 'CLOSED';
    };

    res.json([
        { name: 'NYSE', status: status(13, 30, 20, 0) },
        { name: 'NASDAQ', status: status(13, 30, 20, 0) },
        { name: 'LSE', status: status(8, 0, 16, 30) },
        { name: 'IDX', status: status(1, 30, 9, 0) },
        { name: 'TSE', status: status(0, 0, 6, 0) },
        { name: 'HKEX', status: status(1, 30, 8, 0) },
        { name: 'SGX', status: status(1, 0, 9, 0) },
    ]);
});

app.get('/api/finance', async (req, res) => {
    const type = req.query.type || 'global';
    let symbols = [];

    if (type === 'global') symbols = ['^GSPC', '^IXIC', '^DJI', 'AAPL', 'TSLA', 'MSFT', 'NVDA', 'AMZN', 'GOOGL', 'META'];
    else if (type === 'crypto') symbols = ['BTC-USD', 'ETH-USD', 'SOL-USD', 'BNB-USD', 'DOGE-USD', 'XRP-USD', 'ADA-USD'];
    else if (type === 'forex') symbols = ['EURUSD=X', 'GBPUSD=X', 'JPY=X', 'GC=F', 'CL=F', 'BZ=F', '^TNX', '^VIX', 'DX-Y.NYB'];
    else symbols = ['^GSPC'];

    try {
        const promises = symbols.map(symbol => new Promise((resolve) => {
            https.get(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=15m&range=1d`, {
                headers: { 'User-Agent': 'Mozilla/5.0' }
            }, (response) => {
                let data = '';
                response.on('data', chunk => data += chunk);
                response.on('end', () => {
                    try {
                        const parsed = JSON.parse(data);
                        const result = parsed.chart.result[0];
                        const meta = result.meta;
                        const quotes = result.indicators.quote[0].close || [];
                        const sparkline = quotes.filter(x => x !== null);
                        let peRatio = 'N/A', mcap = 'N/A';
                        if (symbol === 'AAPL') { peRatio = '31.2x'; mcap = '3.21T'; }
                        else if (symbol === 'TSLA') { peRatio = '58.4x'; mcap = '575B'; }
                        else if (symbol === 'MSFT') { peRatio = '35.1x'; mcap = '3.15T'; }
                        else if (symbol === 'NVDA') { peRatio = '68.9x'; mcap = '2.85T'; }
                        else if (symbol === 'AMZN') { peRatio = '41.3x'; mcap = '1.88T'; }
                        else if (symbol === 'GOOGL') { peRatio = '26.8x'; mcap = '2.10T'; }
                        else if (symbol === 'META') { peRatio = '28.4x'; mcap = '1.20T'; }
                        resolve({ symbol, price: meta.regularMarketPrice, prevClose: meta.chartPreviousClose, sparkline: sparkline.slice(-25), peRatio, mcap });
                    } catch (e) {
                        resolve({ symbol, price: 0, prevClose: 0, sparkline: [], peRatio: 'N/A', mcap: 'N/A', error: true });
                    }
                });
            }).on('error', () => resolve({ symbol, price: 0, prevClose: 0, sparkline: [], peRatio: 'N/A', mcap: 'N/A', error: true }));
        }));
        res.json(await Promise.all(promises));
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/news', async (req, res) => {
    try {
        const feed = await parser.parseURL('https://news.google.com/rss/search?q=world+economy+OR+finance+market&hl=en&gl=US&ceid=US:en');
        res.json(feed.items.slice(0, 8).map(item => ({
            title: item.title,
            time: item.pubDate,
            source: item.source || 'WORLDNEWS'
        })));
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Global Macro Country Stats
app.get('/api/macro', async (req, res) => {
    try {
        let usYield = 4.45, usSparkline = [];
        try {
            const r = await new Promise((resolve) => {
                https.get(`https://query1.finance.yahoo.com/v8/finance/chart/^TNX?interval=15m&range=1d`, {
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                }, (response) => {
                    let data = '';
                    response.on('data', chunk => data += chunk);
                    response.on('end', () => {
                        try {
                            const p = JSON.parse(data);
                            const res = p.chart.result[0];
                            const quotes = res.indicators.quote[0].close || [];
                            resolve({ price: res.meta.regularMarketPrice, sparkline: quotes.filter(x => x !== null) });
                        } catch (e) { resolve(null); }
                    });
                }).on('error', () => resolve(null));
            });
            if (r) { usYield = r.price; usSparkline = r.sparkline; }
        } catch (_) {}

        // Fetch RI 10Y Yield for Indonesia Macro
        let idYield = 6.95, idSparkline = [6.9, 6.92, 6.95, 6.94, 6.95];
        try {
            const r = await new Promise((resolve) => {
                https.get(`https://query1.finance.yahoo.com/v8/finance/chart/ID10YTRR?interval=15m&range=1d`, {
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                }, (response) => {
                    let data = '';
                    response.on('data', chunk => data += chunk);
                    response.on('end', () => {
                        try {
                            const p = JSON.parse(data);
                            const res = p.chart.result[0];
                            const quotes = res.indicators.quote[0].close || [];
                            resolve({ price: res.meta.regularMarketPrice, sparkline: quotes.filter(x => x !== null) });
                        } catch (e) { resolve(null); }
                    });
                }).on('error', () => resolve(null));
            });
            if (r) { idYield = r.price; idSparkline = r.sparkline; }
        } catch (_) {}

        res.json([
            { country: 'United States', gdp: '+1.6%', cpi: '3.4%', yield: usYield.toFixed(2) + '%', sparkline: usSparkline.slice(-15), unemployment: '3.9%', keyRate: '5.50%' },
            { country: 'Indonesia', gdp: '+5.11%', cpi: '2.51%', yield: idYield.toFixed(2) + '%', sparkline: idSparkline.slice(-15), unemployment: '4.82%', keyRate: '6.25%' },
            { country: 'China', gdp: '+5.3%', cpi: '0.3%', yield: '2.31%', sparkline: [2.35, 2.34, 2.33, 2.32, 2.31], unemployment: '5.2%', keyRate: '3.45%' },
            { country: 'Eurozone', gdp: '+0.4%', cpi: '2.4%', yield: '2.50%', sparkline: [2.48, 2.49, 2.51, 2.50, 2.50], unemployment: '6.5%', keyRate: '4.50%' },
            { country: 'Japan', gdp: '+0.4%', cpi: '2.5%', yield: '0.95%', sparkline: [0.91, 0.92, 0.94, 0.95, 0.95], unemployment: '2.6%', keyRate: '0.10%' },
            { country: 'UK', gdp: '+0.6%', cpi: '2.3%', yield: '4.22%', sparkline: [4.25, 4.23, 4.24, 4.22, 4.22], unemployment: '4.3%', keyRate: '5.25%' },
            { country: 'India', gdp: '+8.2%', cpi: '5.1%', yield: '7.05%', sparkline: [7.08, 7.06, 7.05, 7.05, 7.05], unemployment: '7.9%', keyRate: '6.50%' },
        ]);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// US Treasury Yield Curve
app.get('/api/bonds', async (req, res) => {
    const fetchYield = (symbol) => new Promise((resolve) => {
        https.get(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=15m&range=1d`, {
            headers: { 'User-Agent': 'Mozilla/5.0' }
        }, (response) => {
            let data = '';
            response.on('data', chunk => data += chunk);
            response.on('end', () => {
                try {
                    const p = JSON.parse(data);
                    const r = p.chart.result[0];
                    const quotes = r.indicators.quote[0].close || [];
                    const sparkline = quotes.filter(x => x !== null).slice(-15);
                    resolve({ price: r.meta.regularMarketPrice, prevClose: r.meta.chartPreviousClose, sparkline });
                } catch(e) { resolve({ price: 0, prevClose: 0, sparkline: [], error: true }); }
            });
        }).on('error', () => resolve({ price: 0, prevClose: 0, sparkline: [], error: true }));
    });

    const [us13w, us5y, us10y, us30y] = await Promise.all([
        fetchYield('^IRX'),
        fetchYield('^FVX'),
        fetchYield('^TNX'),
        fetchYield('^TYX')
    ]);

    const spread = us13w.price > 0 && us10y.price > 0
        ? (us10y.price - us13w.price).toFixed(2)
        : 'N/A';
    const curveStatus = spread !== 'N/A'
        ? (parseFloat(spread) < 0 ? 'INVERTED' : 'NORMAL')
        : 'N/A';

    res.json({ us13w, us5y, us10y, us30y, spread_2y10y: spread, curveStatus });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Tablet 1 Dashboard running at http://localhost:${PORT}`);
});
