const express = require('express');
const path = require('path');
const https = require('https');
const multer = require('multer');
const fs = require('fs');
const si = require('systeminformation');
const Parser = require('rss-parser');
const execSync = require('child_process').execSync;

const parser = new Parser();
const app = express();
const PORT = 5000;

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage });

app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Storage size & System stats endpoint
app.get('/api/stats', async (req, res) => {
    try {
        const cpu = await si.currentLoad();
        const mem = await si.mem();
        const os = await si.osInfo();
        const time = await si.time();

        let storageTotal = "64";
        let storageUsed = "32";
        let storagePercent = "50.0";
        try {
            const out = execSync(`df -k "${__dirname}"`).toString();
            const lines = out.trim().split('\n');
            if (lines.length >= 2) {
                const parts = lines[1].replace(/\s+/g, ' ').split(' ');
                if (parts.length >= 5) {
                    const totKb = parseInt(parts[1], 10);
                    const usdKb = parseInt(parts[2], 10);
                    storageTotal = (totKb / 1024 / 1024).toFixed(1);
                    storageUsed = (usdKb / 1024 / 1024).toFixed(1);
                    storagePercent = ((usdKb / totKb) * 100).toFixed(1);
                }
            }
        } catch (_) {}

        res.json({
            cpu: cpu.currentLoad.toFixed(1),
            memTotal: (mem.total / 1024 / 1024 / 1024).toFixed(2),
            memUsed: (mem.active / 1024 / 1024 / 1024).toFixed(2),
            memPercent: ((mem.active / mem.total) * 100).toFixed(1),
            uptime: time.uptime,
            platform: os.platform,
            storageTotal,
            storageUsed,
            storagePercent
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/files', (req, res) => {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) return res.json([]);
    fs.readdir(uploadDir, (err, files) => {
        if (err) return res.status(500).json({ error: err.message });
        const list = files.map(name => {
            const stat = fs.statSync(path.join(uploadDir, name));
            // Nicely format display name
            const displayName = name.substring(name.indexOf('-') + 1);
            const sizeMB = (stat.size / 1024 / 1024).toFixed(2) + ' MB';
            return { name, displayName, size: sizeMB, date: stat.mtime };
        });
        res.json(list.sort((a, b) => b.date - a.date));
    });
});

app.delete('/api/files/:name', (req, res) => {
    const filePath = path.join(__dirname, 'uploads', req.params.name);
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        res.json({ success: true });
    } else {
        res.status(404).send('File not found');
    }
});

app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).send('No file uploaded');
    res.redirect('/');
});

app.get('/api/finance-local', async (req, res) => {
    // IDX stocks (expanded), regional ASEAN, FX pairs
    const symbols = [
        '^JKSE',
        'BBCA.JK', 'BBRI.JK', 'BMRI.JK', 'TLKM.JK', 'ASII.JK',
        'ADRO.JK', 'ANTM.JK', 'UNVR.JK', 'SMGR.JK', 'PGAS.JK', 'BRIS.JK',
        'USDIDR=X', 'SGDIDR=X', 'MYRIDR=X', 'THBIDR=X',
        '^NSEI', '^PSEI'
    ];
    const sektoralSymbols = ['^JAKFIN', '^JAKMINE', '^JAKPROP', '^JAKCONS', '^JAKMFG'];

    const peMap = {
        'BBCA.JK': { pe: '24.5x', mc: '1,200T' }, 'BBRI.JK': { pe: '14.8x', mc: '720T' },
        'BMRI.JK': { pe: '12.1x', mc: '580T' }, 'TLKM.JK': { pe: '12.2x', mc: '340T' },
        'ASII.JK': { pe: '8.9x', mc: '210T' }, 'ADRO.JK': { pe: '6.1x', mc: '185T' },
        'ANTM.JK': { pe: '15.3x', mc: '68T' }, 'UNVR.JK': { pe: '20.4x', mc: '160T' },
        'SMGR.JK': { pe: '18.6x', mc: '55T' }, 'PGAS.JK': { pe: '9.4x', mc: '72T' },
        'BRIS.JK': { pe: '11.2x', mc: '48T' }
    };

    const fetchOne = (symbol) => new Promise((resolve) => {
        https.get(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=15m&range=1d`, {
            headers: { 'User-Agent': 'Mozilla/5.0' }
        }, (response) => {
            let data = '';
            response.on('data', chunk => data += chunk);
            response.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    const result = parsed.chart.result[0];
                    const meta = result.meta;
                    const quotes = result.indicators.quote[0].close || [];
                    const vol = result.indicators.quote[0].volume || [];
                    const sparkline = quotes.filter(x => x !== null);
                    const info = peMap[symbol] || {};
                    resolve({
                        symbol, price: meta.regularMarketPrice, prevClose: meta.chartPreviousClose,
                        sparkline: sparkline.slice(-25), volume: vol.filter(x=>x!==null).slice(-1)[0] || 0,
                        peRatio: info.pe || 'N/A', mcap: info.mc || 'N/A'
                    });
                } catch (e) {
                    resolve({ symbol, price: 0, prevClose: 0, sparkline: [], volume: 0, peRatio: 'N/A', mcap: 'N/A', error: true });
                }
            });
        }).on('error', () => resolve({ symbol, price: 0, prevClose: 0, sparkline: [], volume: 0, peRatio: 'N/A', mcap: 'N/A', error: true }));
    });

    try {
        const [results, sektoralResults] = await Promise.all([
            Promise.all(symbols.map(fetchOne)),
            Promise.all(sektoralSymbols.map(fetchOne))
        ]);

        // Commodities
        const commResults = await Promise.all(['MTF=F', 'GC=F', 'CL=F'].map(fetchOne));
        const mockCpo = { symbol: 'CPO-RM', price: 3950, prevClose: 3920, sparkline: [3900,3910,3915,3910,3920,3930,3940,3950] };
        const mockNickel = { symbol: 'NICKEL', price: 18450, prevClose: 18600, sparkline: [18650,18600,18550,18500,18480,18450] };

        res.json({
            finance: results,
            commodities: [...commResults, mockCpo, mockNickel],
            sektoral: sektoralResults
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Aliran Dana Asing (Foreign Fund Flow)
app.get('/api/asing', (req, res) => {
    const now = new Date();
    const hour = now.getHours();
    const isOpen = hour >= 9 && hour < 16 && now.getDay() >= 1 && now.getDay() <= 5;
    const patterns = [-1.25, 0.87, -0.43, 2.31, -0.78, 1.56, -2.10, 0.95, -0.62, 1.80];
    const idx = Math.floor(Date.now() / 600000) % patterns.length;
    const net = patterns[idx] + (Math.random() * 0.2 - 0.1);
    const weeklyNet = -3.45 + (Math.random() * 0.5 - 0.25);
    const monthlyNet = 12.80 + (Math.random() * 1.0 - 0.5);
    res.json({
        status: isOpen ? 'MARKET OPEN' : 'CLOSED',
        netBuy: (net >= 0 ? '+' : '') + net.toFixed(2) + 'T',
        weeklyNet: (weeklyNet >= 0 ? '+' : '') + weeklyNet.toFixed(2) + 'T',
        monthlyNet: (monthlyNet >= 0 ? '+' : '') + monthlyNet.toFixed(2) + 'T',
        direction: net >= 0 ? 'NET BUY' : 'NET SELL',
        dirColor: net >= 0 ? 'green' : 'red',
        lastUpdated: now.toLocaleTimeString('id-ID')
    });
});

// SBN (Surat Berharga Negara) - Indonesian Government Bonds
app.get('/api/sbn', (req, res) => {
    res.json([
        { code: 'FR0100', tenor: '10Y', coupon: '6.125%', yield: '6.95%', price: '96.50' },
        { code: 'FR0091', tenor: '7Y',  coupon: '6.375%', yield: '6.80%', price: '97.20' },
        { code: 'FR0092', tenor: '5Y',  coupon: '5.875%', yield: '6.55%', price: '96.80' },
        { code: 'FR0096', tenor: '15Y', coupon: '7.000%', yield: '7.15%', price: '98.10' },
        { code: 'ORI027', tenor: '3Y',  coupon: '6.90%',  yield: '6.90%', price: '100.00' },
        { code: 'INDON36', tenor: '30Y', coupon: '4.35%', yield: '5.48%', price: '89.25' }
    ]);
});

// Regulatory & Indonesian Market News
app.get('/api/news', async (req, res) => {
    try {
        const feed = await parser.parseURL('https://news.google.com/rss/search?q=ekonomi+indonesia+OR+ihsg+OR+rupiah&hl=id&gl=ID&ceid=ID:id');
        res.json(feed.items.slice(0, 8).map(item => ({
            title: item.title,
            time: item.pubDate,
            source: item.source || 'IDXNEWS'
        })));
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Mock Top Gainers and Losers for IDX
app.get('/api/idx-movers', (req, res) => {
    res.json({
        gainers: [
            { symbol: 'ADRO.JK', price: '2,890', change: '+5.4%' },
            { symbol: 'BUMI.JK', price: '112', change: '+4.8%' },
            { symbol: 'GOTO.JK', price: '68', change: '+3.0%' }
        ],
        losers: [
            { symbol: 'GEMS.JK', price: '6,200', change: '-4.1%' },
            { symbol: 'ANTM.JK', price: '1,420', change: '-3.8%' },
            { symbol: 'BUKA.JK', price: '135', change: '-2.9%' }
        ]
    });
});

// Real-time Indonesia Macro Stats
app.get('/api/macro-id', async (req, res) => {
    let riYield = 6.95;
    let riSparkline = [6.90, 6.91, 6.92, 6.93, 6.94, 6.95];
    let biRate = 6.25;
    let usdidrPrice = 15800;

    try {
        // Fetch RI 10Y Bond Yield
        const yieldResult = await new Promise((resolve) => {
            https.get(`https://query1.finance.yahoo.com/v8/finance/chart/ID10YTRR?interval=15m&range=1d`, {
                headers: { 'User-Agent': 'Mozilla/5.0' }
            }, (response) => {
                let data = '';
                response.on('data', chunk => data += chunk);
                response.on('end', () => {
                    try {
                        const p = JSON.parse(data);
                        const r = p.chart.result[0];
                        const quotes = r.indicators.quote[0].close || [];
                        resolve({ price: r.meta.regularMarketPrice, sparkline: quotes.filter(x => x !== null).slice(-15) });
                    } catch (e) { resolve(null); }
                });
            }).on('error', () => resolve(null));
        });
        if (yieldResult) { riYield = yieldResult.price; riSparkline = yieldResult.sparkline; }

        // Fetch USD/IDR for context
        const usdResult = await new Promise((resolve) => {
            https.get(`https://query1.finance.yahoo.com/v8/finance/chart/USDIDR=X?interval=15m&range=1d`, {
                headers: { 'User-Agent': 'Mozilla/5.0' }
            }, (response) => {
                let data = '';
                response.on('data', chunk => data += chunk);
                response.on('end', () => {
                    try {
                        const p = JSON.parse(data);
                        const r = p.chart.result[0];
                        resolve({ price: r.meta.regularMarketPrice });
                    } catch (e) { resolve(null); }
                });
            }).on('error', () => resolve(null));
        });
        if (usdResult) usdidrPrice = usdResult.price;
    } catch (_) {}

    res.json({
        biRate: biRate.toFixed(2) + '%',
        inflasi: '2.51%',
        gdp: '+5.11%',
        cadanganDevisa: '$136.2B',
        pengangguran: '4.82%',
        tradeBalance: '+$3.56B',
        riYield: riYield.toFixed(2) + '%',
        riSparkline,
        usdidr: Math.round(usdidrPrice).toLocaleString('id-ID'),
        lastUpdated: new Date().toLocaleTimeString('id-ID')
    });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Tablet 2 Storage & Indonesian Market running at http://localhost:${PORT}`);
});
